#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>

void error(char *msg) {
	perror(msg);
	exit(1);
}

int main(int argc, char *argv[]) {
	/* local variables*/
	int sockfd, newsockfd, portno, clilen;
	char buffer[256];

	struct sockaddr_in serv_addr, cli_addr;
	int n;
	/*if there isn't a port number in arguments*/
	if (argc < 2) {
		fprintf(stderr,"ERROR, no port provided\n");
		exit(1);
	}
	/*assign variable to socket opening*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	/*If there is an error, socket will return 0*/
	if (sockfd < 0)
		error("ERROR opening socket");
	/*sends sizeof serv_addr bytes to  the server address, sets all to 0*/
	bzero((char *) &serv_addr, sizeof(serv_addr));
	/*get the port number from the argument*/
	portno = atoi(argv[1]);
	/*Sets each part of the server address*/
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);
	/*Bind the socket with the local address, client can now connect*/
	if (bind(sockfd, (struct sockaddr *) &serv_addr,
			sizeof(serv_addr)) < 0)
		error("ERROR on binding");
	/* now accepting connections*/
	listen(sockfd,5);
	clilen = sizeof(cli_addr);
	/*takes the first new connection on the queue*/
	newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
	if (newsockfd < 0)
		error("ERROR on accept");
	bzero(buffer,256);
	/*read the data into the buffer*/
	n = read(newsockfd,buffer,255);
	/*if unsuccessful*/
	if (n < 0) error("ERROR reading from socket");
	printf("Here is the message: %s\n",buffer);
	/*if successful*/
	n = write(newsockfd,"I got your message",18);
	if (n < 0) error("ERROR writing to socket");
	return 0;
}

