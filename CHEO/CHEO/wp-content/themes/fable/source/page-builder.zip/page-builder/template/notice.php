		<div class="pb-plugin-option-notice pb-plugin-option-notice-<?php echo $this->data['type']; ?> pb-clear-fix">
			<span></span>
			<h4><?php echo $this->data['title']; ?></h4>
			<h6><?php echo $this->data['subtitle']; ?></h6>
		</div>