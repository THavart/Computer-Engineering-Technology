Additional Parser Test Files
1. The file ass2r.pls contains syntactically correct program.
   It must be parsed successfully.
2. The file ass4w5op.pls tests your operators implementation.
   Depending on how you have transformed and implemented the relational expression production
   your Parser output must match the errors either in ass4w5op1.out or ass4w5op2.out
3. If you have to make any corrections to your Parser as a result from the additional testing,
   make sure that the standard test files for the Parser still work.

S^R, W17